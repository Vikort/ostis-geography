#include <memory>

#include "sc-memory/sc_memory.hpp"


#include "sc-memory/sc_event.hpp"




#define AdminKeynodes_hpp_14_init  bool _InitInternal() override \
{ \
    ScMemoryContext ctx(sc_access_lvl_make_min, "AdminKeynodes::_InitInternal"); \
    bool result = true; \
    return result; \
}


#define AdminKeynodes_hpp_14_initStatic static bool _InitStaticInternal()  \
{ \
    ScMemoryContext ctx(sc_access_lvl_make_min, "AdminKeynodes::_InitStaticInternal"); \
    bool result = true; \
	action_get_embassy = ctx.HelperResolveSystemIdtf("action_get_embassy", ScType::Node); result = result && action_get_embassy.IsValid(); \
	action_get_admin_building_district = ctx.HelperResolveSystemIdtf("action_get_admin_building_district", ScType::Node); result = result && action_get_admin_building_district.IsValid(); \
	concept_admin_building = ctx.HelperResolveSystemIdtf("concept_admin_building", ScType::Node); result = result && concept_admin_building.IsValid(); \
	action_get_admin_building_region = ctx.HelperResolveSystemIdtf("action_get_admin_building_region", ScType::Node); result = result && action_get_admin_building_region.IsValid(); \
	nrel_region = ctx.HelperResolveSystemIdtf("nrel_region", ScType::Node); result = result && nrel_region.IsValid(); \
	nrel_embassy = ctx.HelperResolveSystemIdtf("nrel_embassy", ScType::Node); result = result && nrel_embassy.IsValid(); \
	nrel_search_area = ctx.HelperResolveSystemIdtf("nrel_search_area", ScType::Node); result = result && nrel_search_area.IsValid(); \
	minsk = ctx.HelperResolveSystemIdtf("minsk", ScType::Node); result = result && minsk.IsValid(); \
    return result; \
}


#define AdminKeynodes_hpp_14_decl 

#define AdminKeynodes_hpp_AdminKeynodes_impl 

#undef ScFileID
#define ScFileID AdminKeynodes_hpp

